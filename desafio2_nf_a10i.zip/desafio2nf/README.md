# NOTAVIA

### Necessita de uma chave OPENAI_API_KEY

Criar um arquivo .env na raiz do projeto e colocar a chave OPENAI_API_KEY.

Utiliza o modelo gpt-4o-mini que possui um custo muito baixo (mais baixo do que versões anteriores como gpt-3.5x).

Não está sendo passado aqui o arquivo ZIP de notas fiscais. 

Para executar, esteja com o prompt do terminal no diretório raiz do projeto e digite:

streamlit run app.py


